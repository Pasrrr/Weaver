package com.api.wx123;

public @interface RequestBody {
}
