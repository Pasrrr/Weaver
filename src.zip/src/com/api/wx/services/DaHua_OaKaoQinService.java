package com.api.wx.services;

import com.api.wx.vo.ExtendVO;
import com.api.wx.vo.InfoVO;
import com.api.wx.vo.ResponseVO;

public interface DaHua_OaKaoQinService {

    String insertWorkAttendance(ExtendVO extendVO);
}
