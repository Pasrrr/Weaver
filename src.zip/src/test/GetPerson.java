package test;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.api.formmode.page.util.Util;
import esteem.jun.wanxiang.req.MasterDateReq;
import weaver.conn.RecordSet;

public class GetPerson {

    public static void main(String[] args) {
        MasterDateReq masterDateReq=new MasterDateReq();
    }
}
