package Dahuaesb;

import com.alibaba.druid.support.logging.Log;
import com.alibaba.druid.support.logging.LogFactory;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import weaver.conn.RecordSet;
import weaver.general.Util;

import java.util.Iterator;
import java.util.Map;

/**
 * @author test
 * @title: DH_SaveVisitorToOAAPI
 * @description: 大华-OA访客签到信息API
 * @date 2023/4/22 12:13
 */
public class DH_SaveVisitorToDHAPI {
    private static Log log = LogFactory.getLog(DH_SaveVisitorToDHAPI.class);
}