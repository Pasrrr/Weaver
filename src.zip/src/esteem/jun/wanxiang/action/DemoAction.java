package esteem.jun.wanxiang.action;

import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class DemoAction implements Action {
    @Override
    public String execute(RequestInfo requestInfo) {
        return null;
    }
}
