package Esb.CW;

public class createForFYBXWorkflow {
}
